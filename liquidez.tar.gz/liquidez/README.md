# Liquidez (fases 1-3)

App web instalable (PWA) en español: **Mercado global**, **libro de órdenes agregado de 7 fuentes**, **mapa de liquidez**, **grabadora** y **Brújula** (lectura del libro para 1m, 5m, 15m, 1h y 4h).
No es una recomendación de inversión. Sin claves ni cuentas: todo son APIs públicas.

## Qué incluye y qué no
- Incluye: fases 1, 2 y 3 (modo sin servidor).
- NO incluye todavía: servidor de Cloudflare, Liquidaciones, Panorama, Flujo, Analista.

## Publicarla en tu iPhone (GitHub Pages, gratis)
1. Crea cuenta en https://github.com/signup .
2. Pulsa «New repository» (https://github.com/new), llámalo `liquidez`, público, y créalo.
3. En el repositorio pulsa «uploading an existing file» y arrastra TODO el contenido de esta carpeta (incluidas `js`, `icons`, `tests`). Pulsa «Commit changes».
4. Ve a Settings → Pages. En «Branch» elige `main` y carpeta `/ (root)`. Guarda.
5. Espera 1-2 minutos. Tu dirección será `https://TU-USUARIO.github.io/liquidez/`.
6. En el iPhone abre esa dirección en **Safari** → botón Compartir → «Añadir a pantalla de inicio».

## Probar sin red
Añade `?demo=1` a la dirección: usa libros SIMULADOS (aviso ámbar arriba). Sirve para ver la pantalla, no para decidir nada.

## Pruebas
`npm test` (Node 20+): sincronización de Binance, contratos de OKX, Bybit, Hyperliquid, agregación e imbalance, señales, niveles y ciclo de vida de la Brújula, Top 20.

## Límites conocidos
- Binance, Bybit y OKX solo publican niveles cercanos; Coinbase y Bitstamp, el libro completo; Hyperliquid agrupa precios.
- iOS para la grabadora y las conexiones si se bloquea la pantalla.
- El índice CMC20 no tiene API gratuita: se calcula un «Top 20» propio.
- Las conexiones reales a los exchanges NO se han podido probar desde el entorno donde se construyó (sin acceso a esas webs): hay que comprobarlas en tu iPhone.
